import { Component, ChangeDetectionStrategy, OnInit, TemplateRef ,AfterViewInit, ViewChild, ViewContainerRef,ElementRef} from '@angular/core';
import { _ } from '@c8y/ngx-components';
import { FormBuilder, FormGroup,FormControl, Validators,FormArray } from '@angular/forms';
import { bootstrap } from 'index';
import { BsModalRef,BsModalService } from 'ngx-bootstrap/modal';
import * as $ from 'jquery' ;
import { WatchInputFormService } from './watchinput-form.service';
import { findIndex } from 'rxjs/operators';

@Component({
  selector: 'app-watchinput-form',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './watchinput-form.component.html',
  styles: [
    `
      .row-margin {
        margin-bottom:14px;
        margin-top:14px
      }
      input[type="checkbox"] {
    }
    label{
      font-weight:bold;
    }
    `
  ]
})
export class WatchInputFormComponent implements OnInit {
  data: any = {};
   
  public formoneData : any = {};
  public id_test : any;
  // public id : any;
  public formPatchData : any = {};
  public is_edit: boolean = false;
  public active : any;
  public CustomerName: any = [
    'Customer A', 'Customer B', 'Customer C', 'Customer D', 'Customer E', 'Customer F','Customer G','Customer H','Customer I','Customer J','Customer K'
  ];
  public CategoryName : any = [
    {name:'Unit',isSelected:false},
    {name:'Water',isSelected:false},
    {name:'Gas',isSelected:false},
    {name:'Steam',isSelected:false},
    {name:'Condensate',isSelected:false}
      // 'Unit', 'Water', 'Gas','Steam', 'Condensate'
    ];

  public Tempraturetype : any = [
    {"value": '0',"name":'Measured'}, 
    {"value": '1',"name":'Arbitrary'},
    {"value": '2',"name":'Chalcedony geothermometer'},
    {"value": '3',"name":'Quartz geothermometer'},
    {"value": '4',"name":'Na/K geothermometer'},
  ];
  // public isdisabled : any = true;
  public isCustomer : boolean = false;
  isMeaserdTemp : boolean =false;
  tabList : any = [];
  modalRef: BsModalRef;
  modalSaveRef : BsModalRef;
  modalReset : BsModalRef;
  message: string;
  templateId : any;
  // isMeaserdTempCheck : boolean =false;
  customerId : any = "";

  formDetails = new FormGroup ({ 
        customer: new FormControl(),
        sample_number: new FormControl(),
        sample_location: new FormControl(), 
        site: new FormControl(),    
        Geothermal_well: new FormControl(), 
        temperature: new FormControl(), 
        pressure:new FormControl(),
        enthalpy:new FormControl(),
        discharge:new FormControl(),
        water_phase_pH : new FormControl(),
        pH_temperature: new FormControl(),
        CO2_in_water: new FormControl(),
        H2S_in_water:new FormControl(),
        NH3_in_water:new FormControl(),
        H2_in_water:new FormControl(),
        O2_in_water:new FormControl(),
        CH4_in_water:new FormControl(),
        N2_in_water:new FormControl(),
        SiO2_in_water:new FormControl(),
        B_in_water:new FormControl(),
        Al_in_water:new FormControl(),
        Fe_in_water:new FormControl(),
        Na_in_water:new FormControl(),
        K_in_water:new FormControl(),
        Mg_in_water:new FormControl(),
        Ca_in_water:new FormControl(),
        F_in_water:new FormControl(),
        Cl_in_water:new FormControl(),
        SO4_in_water:new FormControl(),
        TDS_in_water:new FormControl(),
        gas_CO2:new FormControl(),
        gas_H2S:new FormControl(),
        gas_NH3:new FormControl(),
        gas_H2:new FormControl(),
        gas_O2:new FormControl(),
        gas_CH4:new FormControl(),
        gas_N2:new FormControl(),
        L_gas:new FormControl(),
        gas_coll:new FormControl(),
        steam_CO2:new FormControl(),
        steam_H2S:new FormControl(),
        steam_NH3:new FormControl(),
        condensate_pH:new FormControl(),
        Cd_pH_temp:new FormControl(),
        condensate_CO2:new FormControl(),
        condensate_H2S:new FormControl(),
        condensate_NH3:new FormControl(),
        condensate_Na:new FormControl(),
        inputConfig : new FormGroup({
          customer: new FormControl(),
          username: new FormControl(),  
          printout_heading: new FormControl(),   
          temperature_type : new FormControl(),
          // measured_temperature : new FormControl(),
          input_temperature : new FormControl(),
          outputfilename: new FormControl(),
          inputfilename : new FormControl(),
        }),
    });


  constructor(private formBuilder: FormBuilder,private elementRef:ElementRef,private fb: FormBuilder, private bsModalRef: BsModalRef,private modalService: BsModalService, private watchInputFormService : WatchInputFormService) {
    this.CreateForm();
  }

  ngOnInit(): void {
     this.loadData();
  }

  public CreateForm(){
    this.formDetails = this.formBuilder.group({
      customer : ['' , Validators.required],
      sample_number: {value: '', disabled: true},
      sample_location: {value: '', disabled: true}, 
      site:{value: '' , disabled: true}, 
      Geothermal_well:{value: '' , disabled: true}, 

      temperature: ['0.00000000' , Validators.required],  
      pressure:['0.00000000' , Validators.required], 
      enthalpy:['0.00000000' , Validators.required], 
      discharge:['0.00000000' , Validators.required], 
      
        water_phase_pH : ['0.00000000' , Validators.required], 
        pH_temperature: ['0.00000000' , Validators.required], 
        CO2_in_water: ['0.00000000' , Validators.required], 
        H2S_in_water:['0.00000000' , Validators.required], 
        NH3_in_water:['0.00000000' , Validators.required], 
        H2_in_water:['0.00000000' , Validators.required], 
        O2_in_water:['0.00000000' , Validators.required], 
        CH4_in_water:['0.00000000' , Validators.required], 
        N2_in_water:['0.00000000' , Validators.required], 
        SiO2_in_water:['0.00000000' , Validators.required], 
        B_in_water:['0.00000000' , Validators.required], 
        Al_in_water:['0.00000000' , Validators.required], 
        Fe_in_water:['0.00000000' , Validators.required], 
        Na_in_water:['0.00000000' , Validators.required], 
        K_in_water:['0.00000000' , Validators.required], 
        Mg_in_water:['0.00000000' , Validators.required], 
        Ca_in_water:['0.00000000' , Validators.required], 
        F_in_water:['0.00000000' , Validators.required], 
        Cl_in_water:['0.00000000' , Validators.required], 
        SO4_in_water:['0.00000000' , Validators.required], 
        TDS_in_water:['0.00000000' , Validators.required], 
      
        gas_CO2:['0.00000000' , Validators.required], 
        gas_H2S:['0.00000000' , Validators.required], 
        gas_NH3:['0.00000000' , Validators.required], 
        gas_H2:['0.00000000' , Validators.required], 
        gas_O2:['0.00000000' , Validators.required], 
        gas_CH4:['0.00000000' , Validators.required], 
        gas_N2:['0.00000000' , Validators.required], 
        L_gas:['0.00000000' , Validators.required], 
        gas_coll:['0.00000000' , Validators.required], 
    
        steam_CO2:['0.00000000' , Validators.required], 
        steam_H2S:['0.00000000' , Validators.required], 
        steam_NH3:['0.00000000' , Validators.required], 
     
        condensate_pH:['0.00000000' , Validators.required], 
        Cd_pH_temp:['0.00000000' , Validators.required], 
        condensate_CO2:['0.00000000' , Validators.required], 
        condensate_H2S:['0.00000000' , Validators.required], 
        condensate_NH3:['0.00000000' , Validators.required], 
        condensate_Na: ['0.00000000'],

        inputConfig : this.formBuilder.group({
          customer : [ '' , Validators.required],
          username: ['' , Validators.required],  
          printout_heading: ['' , Validators.required],  
          temperature_type : ['' , Validators.required], 
          // measured_temperature : ['' , Validators.required], 
          input_temperature : ['' , Validators.required], 
          inputfilename : ['' , Validators.required], 
          outputfilename : ['' , Validators.required], 
        }),
      })
  }
  
  public loadData(){
    // debugger;
  // this.watchInputFormService.getData().then(function(response) {
  //    alert("response");
  //  });
  }
  public changeCustomer(e : any){
    this.customerId = e.target.value;
    this.formDetails.controls.customer.setValue(e.target.value);
    this.formDetails.controls['sample_number'].enable();
    this.formDetails.controls['sample_location'].enable();
    this.formDetails.controls['site'].enable();
    this.formDetails.controls['Geothermal_well'].enable();
    this.isCustomer = true;
   };

   public changeTemperature(e : any){
    //  debugger;
     
    if(e.target.value == '0'|| e.target.value == '1')
    {
      this.isMeaserdTemp = true;
    }
   }

  // convenience getter for easy access to form fields
  // get f() { return this.waterGroup.controls, this.generalGroup.controls,this.generalGroup.controls ; }
  get f() { return this.formDetails.controls; }
  // get f() { return this.generalGroup.controls; }


 
  tabs: any[] = [
    { title: 'General', content: 'General' , disabled: false, active:true},
    { title: 'Submit', content: 'Submit',disabled: false }
  ];
  
  public changeCategory(e : any){
    // debugger;
    this.addNewTab(e);
    
 }

  addNewTab(event : any): void {
    // debugger;
    if(event.target.value)
    if(this.tabList.includes(event.target.value))
    {
      return;
    }
    else{
      this.tabs.forEach(x=> {
        if(x.title == 'Submit')
         this.tabs.splice(this.tabs.indexOf(x), 1);
       })

      this.tabs.push({
        title: event.target.value,
        content: event.target.value,
        disabled: false,
        active:true,
        removable: true
      },
      {
        title: 'Submit',
        content: 'Submit',
        disabled: false,
        active:false,
        removable: false
      });

      this.tabList.push(event.target.value);
    }
}

  removeTabHandler(tab: any): void {
    // debugger;
    this.tabs.splice(this.tabs.indexOf(tab), 1);
    this.resetTabValue(tab.title);
    // console.log('Remove Tab handler');
    // console.log(this.tabList.indexOf(tab));
    this.tabList.splice(this.tabList.indexOf(tab.title), 1);
  }


  public resetTabValue(title : any){
    // debugger;
     if(title == 'Unit')
      this.formDetails.patchValue({
        temperature: '0.00000000', 
        pressure: '0.00000000', 
        enthalpy: '0.00000000', 
        discharge: '0.00000000', 
      });

      else if(title == 'Water'){
        this.formDetails.patchValue({
          water_phase_pH : '0.00000000', 
          pH_temperature: '0.00000000', 
          CO2_in_water: '0.00000000', 
          H2S_in_water:'0.00000000' , 
          NH3_in_water:'0.00000000' , 
          H2_in_water:'0.00000000', 
          O2_in_water:'0.00000000' , 
          CH4_in_water:'0.00000000', 
          N2_in_water:'0.00000000', 
          SiO2_in_water:'0.00000000', 
          B_in_water:'0.00000000', 
          Al_in_water:'0.00000000', 
          Fe_in_water:'0.00000000', 
          Na_in_water:'0.00000000', 
          K_in_water:'0.00000000', 
          Mg_in_water:'0.00000000', 
          Ca_in_water:'0.00000000', 
          F_in_water:'0.00000000', 
          Cl_in_water:'0.00000000', 
          SO4_in_water:'0.00000000', 
          TDS_in_water:'0.00000000', 
        });
      }

        else if(title == 'Gas'){
          this.formDetails.patchValue({
            gas_CO2:'0.00000000', 
            gas_H2S:'0.00000000', 
            gas_NH3:'0.00000000', 
            gas_H2:'0.00000000', 
            gas_O2:'0.00000000', 
            gas_CH4:'0.00000000', 
            gas_N2:'0.00000000', 
            L_gas:'0.00000000', 
            gas_coll:'0.00000000'
          })
        }

        else if(title == 'Steam'){
          this.formDetails.patchValue({
            steam_CO2:'0.00000000',
            steam_H2S:'0.00000000' ,
            steam_NH3:'0.00000000' 
          });
        }

        else if(title == 'Condensate'){
          this.formDetails.patchValue({
            condensate_pH:'0.00000000' , 
            Cd_pH_temp:'0.00000000' ,
            condensate_CO2:'0.00000000',
            condensate_H2S:'0.00000000',
            condensate_NH3:'0.00000000',
            condensate_Na: '0.00000000',
          })
        }

  }

  Next(){
    // debugger;
    for(let i =0; i<= this.tabs.length-1; i++)
    {
      // alert(this.tabs[i]);
      // console.log(this.tabs[i]);
      if(this.tabs[i].active){
        let index = i+1;
        this.tabs[index].active = true;
        break;
      }
    }
    // console.log(this.tabs);
  }

  Back(){
    // debugger;
    for(let i =0; i<= this.tabs.length-1; i++)
    {
      // alert(this.tabs[i]);
      // console.log(this.tabs[i]);
      if(this.tabs[i].active){
        let index = i-1;
        this.tabs[index].active = true;
      }
    }
    // console.log(this.tabs);
  }
    

  public Submit(template: TemplateRef<any>){
    // debugger;
    this.formDetails.get('inputConfig.customer').patchValue(this.formDetails.get('customer').value);
    this.modalRef = this.modalService.show(template, {
      class: 'modal-lg',
      ariaDescribedby: 'my-modal-description',
      ariaLabelledBy: 'my-modal-title'
    });
  }

  public SubmitFormData(): void {
    // debugger;
    let tempobj : any = this.formDetails.value;
    alert(JSON.stringify(tempobj));
    // console.log(JSON.stringify(tempobj));
    this.watchInputFormService.postFormData(tempobj);
    this.modalRef.hide();
  }
 
  decline(): void {
    this.modalRef.hide();
  }

  public onReset(templateReset: TemplateRef<any>){
    this.modalReset = this.modalService.show(templateReset, {
      ariaDescribedby: 'my-modal-description',
      ariaLabelledBy: 'my-modal-title'
    });
  }

  public Reset(){
    // debugger;
    this.formDetails.reset();
    this.modalReset.hide();
    this.customerId = "";
    // console.log(this.formDetails.value);
    this.CreateForm();
  }
  
  cancel(): void {
    this.modalReset.hide();
  }

  
}

// public  updateProfile() {
//   //  debugger;
//     this.formDetails.patchValue({
//       customer :this.formPatchData.customer,
//       sample_number: this.formPatchData.sample_number,
//       sample_location : this.formPatchData.sample_location,
//       Temperature_C : this.formPatchData.Temperature_C,
//       pressure : this.formPatchData.pressure,
//       enthalpy : this.formPatchData.enthalpy,
//       discharge : this.formPatchData.discharge,
//       water_phase_pH : this.formPatchData.water_phase_pH,
//       pH_temperature : this.formPatchData.pH_temperature,
//       CO2_in_water : this.formPatchData.CO2_in_water,
//       H2S_in_water : this.formPatchData.H2S_in_water,
//       NH3_in_water : this.formPatchData.NH3_in_water,
//       H2_in_water : this.formPatchData.H2_in_water,
//       O2_in_water : this.formPatchData.O2_in_water,
//       CH4_in_water : this.formPatchData.CH4_in_water,
//       N2_in_water : this.formPatchData.N2_in_water,
//       SiO2_in_water : this.formPatchData.SiO2_in_water,
//       B_in_water : this.formPatchData.B_in_water,
//       Al_in_water : this.formPatchData.Al_in_water,
//       Fe_in_water : this.formPatchData.Fe_in_water,
//       Na_in_water : this.formPatchData.Na_in_water,
//       K_in_water : this.formPatchData.K_in_water,
//       Mg_in_water : this.formPatchData.Mg_in_water,
//       Ca_in_water : this.formPatchData.Ca_in_water,
//       F_in_water : this.formPatchData.F_in_water,
//       Cl_in_water : this.formPatchData.Cl_in_water,
//       SO4_in_water : this.formPatchData.SO4_in_water,
//       TDS_in_water : this.formPatchData.TDS_in_water,
//       gas_CO2 : this.formPatchData.gas_CO2,
//       gas_H2S : this.formPatchData.gas_H2S,
//       gas_NH3 : this.formPatchData.gas_NH3,
//       gas_H2 : this.formPatchData.gas_H2,
//       gas_O2 : this.formPatchData.gas_O2,
//       gas_CH4 : this.formPatchData.gas_CH4,
//       gas_N2 : this.formPatchData.gas_N2,
//       L_gas : this.formPatchData.L_gas,
//       gas_coll : this.formPatchData.gas_coll,
//       steam_CO2 : this.formPatchData.steam_CO2,
//       steam_H2S : this.formPatchData.steam_H2S,
//       steam_NH3 : this.formPatchData.steam_NH3,
//       condensate_pH : this.formPatchData.condensate_pH,
//       Cd_pH_temp : this.formPatchData.Cd_pH_temp,
//       Condensate : this.formPatchData.Condensate,
//       condensate_H2S : this.formPatchData.condensate_H2S,
//       condensate_NH3 : this.formPatchData.condensate_NH3,
//       condensate_Na : this.formPatchData.condensate_Na
//     });
//   }

 
 

  // isCondensate : boolean = false;
  // isSteam : boolean = false;
  // isGas : boolean = false;
  // isWater : boolean = false;
  // isUnit : boolean = false; 

    // removeTab(e : any){ 
  //   debugger;
  //   // alert(e);
  // }

    // openModal(template: TemplateRef<any>) {
  //   debugger;
  //   this.modalRef = this.modalService.show(template, {class: 'modal-lg'});
  //   console.log(this.formDetails.get(['inputConfig','customer']).value);
  // }

    // public Save(id: any, templateSave: TemplateRef<any>){
  //   debugger;
  //   this.modalSaveRef = this.modalService.show(templateSave, {
  //     ariaDescribedby: 'my-modal-description',
  //     ariaLabelledBy: 'my-modal-title'
  //   });

  //   this.templateId = id;
  // }

    // public tempSave(){
  //   debugger;
  //   for(let i =0; i<=this.tabs.length-1; i++)
  //   {
  //     if(this.tabs[i].title == this.templateId)
  //     {
  //       this.tabs[i].disabled = true;
  //       this.tabs[i].removable = false;
  //     }
  //   }
  //   this.modalSaveRef.hide();
  // }