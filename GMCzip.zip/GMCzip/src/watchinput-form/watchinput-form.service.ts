import { Injectable } from '@angular/core';
import { _ } from '@c8y/ngx-components';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FetchClient  } from '@c8y/ngx-components/api';
import { IFetchResponse, IFetchOptions } from '@c8y/client';
import { HttpClient, HttpHeaders, HttpErrorResponse} from "@angular/common/http";
import { Observable, BehaviorSubject, throwError, } from 'rxjs';
import { catchError } from 'rxjs/operators'

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
  })
}

@Injectable()
export class WatchInputFormService {
  dataToDisplay: any[];
  public data: any[];

  constructor(private modalService: BsModalService,private fetchClient: FetchClient, private http: HttpClient) {
  }

  endpoint = "http://172.0.48.198:8080/";

  public postFormData(data : any): Observable<any> {
    debugger;
    let url = this.endpoint + "api/watch/create/";
    return this.http.post(url,data, httpOptions );
  }

  public getFormData(): Observable<any> {
    debugger;
    let url = this.endpoint + "api/watch/";
    return this.http.get(url, httpOptions );

  }

  // async postData(data : any) {
  //   const options: IFetchOptions = {
  //       method: 'POST',
  //       headers: { 'Content-Type': 'application/json' }
  //     };
  //   let url = this.endpoint + "api/watch/create/";

  //   const response = await this.fetchClient.fetch(url, options ); // Fetch API Response
  // }

  // async getData() {
  //   debugger;
  //   const options: IFetchOptions = {
  //       method: 'GET',
  //       headers: { 'Content-Type': 'application/json' },
  //       mode: 'cors'
  //     };

  //   let url = this.endpoint + "api/watch/";
  //   const response = await this.fetchClient.fetch(url, options); // Fetch API Response
  //   return response;
  // }

  // let url = "http://api.plos.org/search?q=title:%22Drosophila%22%20and%20body:%22RNA%22&fl=id,abstract";
}
