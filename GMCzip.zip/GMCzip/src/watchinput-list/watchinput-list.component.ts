import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { _ } from '@c8y/ngx-components';
import { WatchInputService } from './watchinput-list.service';
import {
  ActionControl,
  BuiltInActionType,
  BulkActionControl,
  Column,
  ColumnDataRecordClassName,
  Pagination
} from '@c8y/ngx-components';
import { CellRendererExampleComponent } from './cell-renderer-example.component';
import { getFakeData } from './fake-data';


@Component({
  selector: 'app-watchinput-list',
  templateUrl: './watchinput-list.component.html'
})
export class WatchInputListComponent {
  data: any = {};
  watchInput : any;
  fakeData: any[];

  constructor(public watchInputService : WatchInputService, public router : Router) {
    this.watchInput = this.watchInputService.data ;
    this.fakeData = getFakeData();
  }

  ngOninit(){
    debugger;
    this.watchInput = this.watchInputService.data ;
    this.fakeData = getFakeData();
  }

  public AddRecord(){
    this.router.navigate(['/watchinput-form']);
  }

  columns: Column[] = [
    {
      name: 'customer',
      header: 'Customer',
      path: 'customer',
      cellCSSClassName: ColumnDataRecordClassName.Header,
      filterable: true,
      // cellRendererComponent: CellRendererExampleComponent
    },
    {
      name: 'Sample_number',
      header: 'Sample Number',
      path: 'Sample_number',
      filterable: true,
      // cellRendererComponent: CellRendererExampleComponent
    },
    { name: 'sample_location', header: 'Description', path: 'sample_location' },
    { name: 'data_time', header: 'Date Time', path: 'data_time' }
  ];
  pagination: Pagination = {
    pageSize: 5,
    currentPage: 1
  };
  actionControls: ActionControl[] = [
    { type: BuiltInActionType.Delete, callback: item => console.dir(item) },
    { type: BuiltInActionType.Edit, callback: item => console.dir(item) },
    { type: BuiltInActionType.Delete, callback: item => console.dir(item) }
  ];
  bulkActionControls: BulkActionControl[] = [
    { type: BuiltInActionType.Export, callback: selectedItemIds => console.dir(selectedItemIds) },
    { type: BuiltInActionType.Delete, callback: selectedItemIds => console.dir(selectedItemIds) }
  ];

  handleItemsSelect(selectedItemIds) {
    console.log('selected item ids:');
    console.dir(selectedItemIds);
  }

  handleClick() {
    this.fakeData[0].id = Math.random();
  }

}