export function getFakeData() {
    return [{
    "customer":"Customer A",
    "Sample_number": "1",
    "sample_location": "TP-01",
    "data_time": "2020-02-20 03:30:00"
  },
  {
    "customer":"Customer B",
    "Sample_number": "2",
    "sample_location": "TP-02",
    "data_time": "2020-02-20 03:30:00"
  },
  
  {
    "customer":"Customer F",
    "Sample_number": "6",
    "sample_location": "TP-06",
    "data_time": "2020-02-20 03:30:00"
  },
  {
    "customer":"Customer G",
    "Sample_number": "7",
    "sample_location": "TP-07",
    "data_time": "2020-02-20 03:30:00"
  },
  {
    "customer":"Customer H",
    "Sample_number": "8",
    "sample_location": "TP-08",
    "data_time": "2020-02-20 03:30:00"
  },
  {
    "customer":"Customer I",
    "Sample_number": "9",
    "sample_location": "TP-09",
    "data_time": "2020-02-20 03:30:00"
  },
  {
    "customer":"Customer C",
    "Sample_number": "3",
    "sample_location": "TP-03",
    "data_time": "2020-02-20 03:30:00"
  },
  {
    "customer":"Customer D",
    "Sample_number": "4",
    "sample_location": "TP-04",
    "data_time": "2020-02-20 03:30:00"
  },
  {
    "customer":"Customer E",
    "Sample_number": "5",
    "sample_location": "TP-05",
    "data_time": "2020-02-20 03:30:00"
  },
  {
    "customer":"Customer J",
    "Sample_number": "10",
    "sample_location": "TP-10",
    "data_time": "2020-02-20 03:30:00"
  },
  {
    "customer":"Customer K",
    "Sample_number": "11",
    "sample_location": "TP-10",
    "data_time": "2020-02-20 03:30:00"
  }
]
};

