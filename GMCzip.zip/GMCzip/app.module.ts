import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule as ngRouterModule, Routes } from '@angular/router';
import { ContextDashboardModule } from '@c8y/ngx-components/context-dashboard';
import { HttpClientModule } from '@angular/common/http';

import {
  CoreModule,
  HOOK_ACTION,
  HOOK_BREADCRUMB,
  HOOK_NAVIGATOR_NODES,
  HOOK_TABS,
  BootstrapComponent,
  RouterModule,
  ViewContext,
  HOOK_ONCE_ROUTE,
  HOOK_DOCS
} from '@c8y/ngx-components';

import { RandomGuard } from './guards/random.guard';
import { ExampleNavigationFactory } from './factories/Navigation';

// NOT RECOMMENDED (Angular 9 doesn't support this kind of import)

import { ExampleDocLinkFactory } from './factories/DocLink';
import { WatchInputFormComponent } from './src/watchinput-form/watchinput-form.component';
import { WatchInputListComponent } from './src/watchinput-list/watchinput-list.component';
import { WatchInputService } from './src/watchinput-list/watchinput-list.service';
import { WatchInputFormService } from './src/watchinput-form/watchinput-form.service';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { BsModalRef } from 'ngx-bootstrap/modal';
 /**
 * Angular Routes.
 * Within this array at least path (url) and components are linked.
 */
const appRoutes: Routes = [
  {
    path: 'watchinput-form',
    component: WatchInputFormComponent
  },
  {
    path: 'watchinput-list',
    component: WatchInputListComponent
  },
  {
    path: '',
    redirectTo: 'watchinput-list',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    WatchInputFormComponent,
    WatchInputListComponent
  ],
  imports: [
    BrowserAnimationsModule,
    ngRouterModule.forRoot(appRoutes, { enableTracing: false, useHash: true }),
    RouterModule.forRoot(),
    // Import the CoreModule to add c8y functionality
    CoreModule.forRoot(),
    TabsModule.forRoot(),
    BsDropdownModule.forRoot(),
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    ContextDashboardModule.config()
  ],
  /**
   * Use our predefined InjectionTokens and provide your own classes to extend behavior
   * and functionality of existing ones. Implement your own NavigationNodes, Tabs, Actions and Breadcrumbs
   */
  providers: [
    BsModalRef,
    RandomGuard,
    { provide: HOOK_NAVIGATOR_NODES, useClass: ExampleNavigationFactory, multi: true },

    WatchInputService,
    WatchInputFormService,
  ],
  /**
   * Bootstrap your application with the BootstrapComponent which will use the `<c8y-bootstrap>`
   * component to initialize the root application. Alternatively you can bootstrap
   * a component of your choice and include that tag into its template or only reuse the given components
  */
  bootstrap: [BootstrapComponent],
  /**
   * The EntryComponents to allow the HOOK_ONCE_ROUTE to work.
   */
  entryComponents: [
  ]
})
export class AppModule {}
